GUI filemanager

Thank you for downloading! Included GUI notepad
can be used to view text for files.